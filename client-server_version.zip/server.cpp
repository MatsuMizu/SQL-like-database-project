#include "command_list.h"

int read_from_client(int fd, char *buf) {
    int nbytes = 0, len = 0, i;
    if (read(fd, &len, sizeof(int)) != (int)sizeof(int)) {
        perror("Read from client: length");
        exit(EXIT_FAILURE);
    }
    for (i = 0; len > 0; i += nbytes, len -= nbytes) {
        nbytes = (int)read(fd, buf + i, len);
        if (nbytes < 0) {
            perror("Read from client: nbytes < 0");
            exit(EXIT_FAILURE);
        }
        else if (nbytes == 0) {
            perror("Read from client: read truncated");
            exit(EXIT_FAILURE);
        }
    }
    if (i == 0) {
        perror("Read from client: no message");
        exit(EXIT_FAILURE);
    }
    return SUCCESS;
}

int safe_strcmp(const char* x, const char* y)
{
    if (y == nullptr)
    {
        if (x != nullptr)
            return 1;
        return 0;
    }
    if (x == nullptr)
        return -1;
    return strcmp(x, y);
}

int read_config()
{
    FILE* fcf;
    fcf = fopen("config.txt", "r");
    if (!fcf) {
        printf("Can't open config.txt\n");
        return ERROR_OPEN;
    }
    char buf[LEN];
    int k = 0;
    while (fgets(buf, LEN, fcf)) {
        if (buf[0] && buf[0] == '#') {
            continue;
        }
        if (record::scan_int(buf, &k)) {
            fclose(fcf);
            return k;
        }
    }
    fclose(fcf);
    return ERROR_CONFIG;
}

int main(int argc, char* argv[]) {
    char* file_STU = 0;
    int port = 0;
    if (!(argc == 3 && sscanf(argv[2], "%d", &port) == 1)) {
        printf("Usage %s: file port\n", argv[0]);
        return ERROR_INPUT;
    }
    int k = 1;
#if !debug_helpers
    k = read_config();
#endif
    if (k <= 0) {
        printf("Unexpected config.txt content\n");
        return ERROR_CONFIG;
    }
    file_STU = argv[1];
    FILE* STU;
    STU = fopen(file_STU, "r+");
    if (!STU) {
        printf("Cannot open %s\n", file_STU);
        return ERROR_OPEN;
    }
    huge_database<list1>* dbb = new huge_database<list1>(k);
    if (!dbb) {
        printf("Not enough memory!\n");
        fclose(STU);
        return ERROR_MEMORY;
    }
    io_status reading_res = dbb->read(STU);
    if (reading_res != io_status::success) {
        delete dbb;
        fclose(STU);
        return ERROR_READ;
    }
#if debug_helpers
    dbb->print();
#endif
    fclose(STU);


    // SOCKET THING
    int opt = 1;
    int sock = 0, new_sock = 0;
    socklen_t size;
    struct sockaddr_in server_address;
    struct sockaddr_in client;

    sock = socket(PF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Server: failed to create socket");
        exit(EXIT_FAILURE);
    }
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char*) &opt, sizeof(opt));
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port);
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    int ser_res = bind(sock, (struct sockaddr *)&server_address, sizeof(server_address));
    if (ser_res < 0) {
        perror("Server: failed to bind");
        exit(EXIT_FAILURE);
    }
    ser_res = listen(sock, QUEUE_SIZE);
    if (ser_res < 0) {
        perror("Server: failed to listen");
        exit(EXIT_FAILURE);
    }
    fd_set active_set;
    FD_ZERO(&active_set);
    FD_SET(sock, &active_set);
    char buf[LEN] = {}, air[LEN] = {};
    std::unique_ptr<int[]> cmd_return = std::make_unique<int[]>(FD_SETSIZE);
    command* comm = new command();
    if (!comm) {
        printf("Not enough memory!\n");
        return ERROR_MEMORY;
    }
    command* extra_cmd = new command(command_type::del, condition::eq, condition::eq, condition::eq, operation::land);
    if (!extra_cmd) {
        printf("Nor enough memory for extra command!\n");
        delete comm;
        return ERROR_MEMORY;
    }
    comm->get_spaces(" \t\r\n");
    while (true) {
        fd_set read_set = active_set;
        int select_result = select(FD_SETSIZE, &read_set, NULL, NULL, NULL);
        if (select_result < 0) {
            perror("Server: cannot select - listen queue failure\n");
            return EXIT_FAILURE;
        }
        for (int i = 0; i < FD_SETSIZE; i++) {
            if (FD_ISSET(i, &read_set)) {
                if (i == sock) {
                    printf("New connection\n");
                    size = sizeof(client);
                    new_sock = accept(sock, (struct sockaddr *)&client, &size);
                    if (new_sock < 0) {
                        perror("Error: could not accept connection");
                        return EXIT_FAILURE;
                    }
                    FD_SET(new_sock, &active_set);
                }
                else
                {
                    ser_res = read_from_client(i, buf);
                    size_t buf_position = 0;
#if debug_helpers
                    printf("BUFFER FROM CLIENT = %s\n", buf);
#endif
                    if (ser_res < 0) {
                        close(i);
                        FD_CLR(i, &active_set);
                    }
                    else {
                        if (buf[buf_position] == '\n' || buf[buf_position] == '\r') {
                            comm->set_type(command_type::quit);
                        }
                        else if (!comm->parse(buf, strlen(buf), buf_position, air)) {
                            printf("Parse error in line: %s\n", buf);
                        }
                        if (comm->get_type() == command_type::quit) {
                            printf("Session was closed by client\n");
                            response server_want = response::all_finish;
                            if (write(i, &server_want, sizeof(response)) < 0) {
                                perror("Error: dk smth went wrong");
                                return EXIT_FAILURE;
                            }
                            close(i);
                            FD_CLR(i, &active_set);
                            cmd_return[i] = 0;
                            break;
                        }
                        else if (comm->get_type() == command_type::stop) {
                            printf("Server was stopped by client\n");
                            prnt_utils::my_write_sock(i, "Server was stopped by client\n");
                            response server_want = response::all_finish;
                            if (write(i, &server_want, sizeof(response)) != (int)sizeof(response)) {
                                perror("Error: dk smth also went wrong");
                                return EXIT_FAILURE;
                            }
                            close(i);
                            FD_CLR(i, &active_set);
                            close(sock);
                            delete dbb;
                            delete comm;
                            delete extra_cmd;
                            return SUCCESS;
                        }
                        else {
#if debug_helpers
                            comm->print();
#endif
                            int &answer_field = cmd_return[i];
                            command_list::apply(comm, extra_cmd, dbb, answer_field, i);
#if debug_helpers
                            printf("Curr database:\n");
                            dbb->print();
#endif
                            response server_want = response::finish;
                            if (write(i, &server_want, sizeof(response)) != (int)sizeof(response)) {
                                perror("Error: dk smth went wrong another time");
                                return EXIT_FAILURE;
                            }
                            if (write(i, &answer_field, sizeof(int)) != (int)sizeof(int)) {
                                perror("Error: write cmd_return[i]");
                                return EXIT_FAILURE;
                            }
                        }
                    }
                }
            }
        }
    }
    delete dbb;
    return SUCCESS;
}
