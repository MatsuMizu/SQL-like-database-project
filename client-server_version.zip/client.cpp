#include "my_print.h"

int write_to_server(int fd) {
    int nbytes = 0, len = 0;
    char buf[LEN] = {};
    if (!fgets(buf, LEN, stdin)) {
        return ERROR_READ;
    }
    len = strlen(buf);
    if (buf[0] == '\n' || buf[0] == '\r') exit(EXIT_FAILURE);
    if (write(fd, &len, sizeof(int)) != (int)sizeof(int)) {
        perror("Write to server: length");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; len > 0; i += nbytes, len -= nbytes) {
        nbytes = (int)write(fd, buf + i, len);
        if (nbytes < 0) {
            perror("Write to server: nbytes < 0");
            exit(EXIT_FAILURE);
        }
        else if (nbytes == 0) {
            perror("Write to server: write truncated");
            exit(EXIT_FAILURE);
        }
    }
    return SUCCESS;
}

int read_from_server(int fd) {
    int nbytes = 0, len = 0, cmd_res = 0;
    char buf[LEN] = {};
    response serv_response;
    while (true) {
        if (read(fd, &serv_response, sizeof(response)) != sizeof(response))
            return ERROR;
        if (serv_response == response::finish) {
            if (read(fd, &cmd_res, sizeof(int)) != (int)sizeof(int)) {
                perror("Read from server: read res command");
                exit(EXIT_FAILURE);
            }
            return cmd_res;
        }
        else if (serv_response == response::all_finish)
            return -1;
        else if (serv_response == response::none) {
            if (read(fd, &len, sizeof(int)) != (int)sizeof(int)) {
                perror("Read from server: length");
                exit(EXIT_FAILURE);

            }
            for (int i = 0; len > 0; i += nbytes, len -= nbytes) {
                nbytes = (int)read(fd, buf +  i, len);
                if (nbytes < 0) {
                    perror("Read from server: read nbytes < 0");
                    exit(EXIT_FAILURE);
                }
                else if (nbytes == 0) {
                    perror("Read from server: read nbytes = 0 - read truncated");
                    exit(EXIT_FAILURE);
                }
            }
            printf("%s", buf);
        }
        else {
            perror("Read from server: something bad happened");
            exit(EXIT_FAILURE);
        }
    }
    return SUCCESS;
}


int main (int argc, const char * argv[]) {
    int port = 0;
    const char *server_name = nullptr;
    if (argc != 3 || sscanf(argv[2], "%d", &port) != 1) {
        printf("Usage %s: file port\n", argv[0]);
        return ERROR_INPUT;
    }
    server_name = argv[1];

    // SOCKET THING
    int bytes_set = 0;
    struct sockaddr_in server_addr;
    struct hostent* hostinfo;
    hostinfo = gethostbyname(server_name);
    if (hostinfo == NULL) {
        fprintf(stderr, "Unknown host %s.\n", server_name);
        exit(EXIT_FAILURE);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr = *(struct in_addr*)hostinfo->h_addr;
    int sock = socket(PF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Client: failed to create socket");
        exit(EXIT_FAILURE);
    }
    int clnt_res = connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr));
    if (clnt_res < 0) {
        perror("Client: connect failure");
        exit(EXIT_FAILURE);
    }
#if debug_helpers
    fprintf(stdout, "Connection is ready\n");
#endif
    int result = 0;
    while (true) {
        if (write_to_server(sock) < 0) {
            break;
        }
        bytes_set = read_from_server(sock);
        if (bytes_set >= 0)
            result = bytes_set;
    }
    printf("%s : Result = %d\n", argv[0], result);
    close(sock);
    exit(EXIT_SUCCESS);
}
