#include "condition.h"

#ifndef print_macro
#define print_macro
class prnt_utils
{
public:
    static int my_printf(int fd, const char *format, ...) {
        char buf[LEN];
        va_list ap;
        va_start(ap, format);
        int res = vsnprintf(buf, LEN, format, ap);
        va_end(ap);
        if (res != (int)write(fd, buf, res)) {
            return ERROR;
        }
        return res;
    }

    static int my_write_sock(int fd, const char *buf) {
        int nbytes = 0;
        response server_want = response::none;
        if (write(fd, &server_want, sizeof(response)) != (int)sizeof(response)) {
            perror("My write sock: failed to write in sock");
            exit(EXIT_FAILURE);
        }
        int len = (int)strlen(buf) + 1;
        if (write(fd, &len, sizeof(int)) != (int)sizeof(int)) {
            perror("My write sock: failed to write length");
            exit(EXIT_FAILURE);
        }
        for (int i = 0; len > 0; i += nbytes, len -= nbytes) {
            nbytes = (int)write(fd, buf + i, len);
            if (nbytes < 0) {
                perror("My write sock: nbytes < 0");
                exit(EXIT_FAILURE);
            }
            else if (nbytes == 0) {
                perror("My write sock: write truncated");
                exit(EXIT_FAILURE);
            }
        }
        return SUCCESS;
    }

    static int write_no_element(int fd) {
        my_write_sock(fd, "No such elements in data base\n\n");
        return SUCCESS;
    }

    static int write_error(int fd) {
        my_write_sock(fd, "Server failed to apply command\n\n");
        return SUCCESS;
    }
};
#endif
